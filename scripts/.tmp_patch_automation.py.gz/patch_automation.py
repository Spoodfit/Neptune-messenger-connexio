from pathlib import Path
from textwrap import dedent
import base64
import re

ROOT = Path('.')


def read(path: str) -> str:
    return (ROOT / path).read_text(encoding='utf-8')


def write(path: str, content: str) -> None:
    target = ROOT / path
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(content, encoding='utf-8')


def replace_once(path: str, old: str, new: str) -> None:
    text = read(path)
    if old not in text:
        raise RuntimeError(f'marker missing in {path}: {old[:120]!r}')
    write(path, text.replace(old, new, 1))


def replace_all(path: str, old: str, new: str) -> None:
    text = read(path)
    if old not in text:
        raise RuntimeError(f'marker missing in {path}: {old[:120]!r}')
    write(path, text.replace(old, new))


def regex_once(path: str, pattern: str, replacement: str, flags=0) -> None:
    text = read(path)
    next_text, count = re.subn(pattern, replacement, text, count=1, flags=flags)
    if count != 1:
        raise RuntimeError(f'regex marker missing/ambiguous in {path}: {pattern[:120]!r} count={count}')
    write(path, next_text)


# ---------------------------------------------------------------------------
# Scheduling policy and richer automation model.
# ---------------------------------------------------------------------------
replace_once(
    'src/domain/scheduledMessages.ts',
    'const AUTHORIZED_ROLES = new Set(["capitaine", "amiral", "visionnaire", "admin"]);',
    'const RESPONSIBLE_ROLES = new Set(["capitaine", "amiral"]);'
)
replace_once(
    'src/domain/scheduledMessages.ts',
    '  return (\n    canManageConversation && AUTHORIZED_ROLES.has(normalizeUserRole(role))\n  );',
    '  const normalized = normalizeUserRole(role);\n  return (\n    normalized === "visionnaire" ||\n    normalized === "admin" ||\n    (canManageConversation && RESPONSIBLE_ROLES.has(normalized))\n  );'
)
replace_once(
    'src/domain/scheduledMessages.ts',
    '      "Seuls les Capitaines, Amiraux et Visionnaires responsables de ce groupe peuvent programmer un message."',
    '      "Seuls les Visionnaires et les responsables désignés de ce groupe peuvent créer une automatisation."'
)
# Extend input model.
replace_once(
    'src/domain/scheduledMessages.ts',
    '  body: string;\n  attachments?: MessageAttachment[];',
    '  name?: string;\n  body: string;\n  attachments?: MessageAttachment[];\n  recurrence?: "none" | "daily" | "weekly" | "monthly";\n  createdByName?: string;'
)
replace_once(
    'src/domain/scheduledMessages.ts',
    '    body: cleanBody,\n    attachments,\n    scheduledFor:',
    '    name: input.name?.trim() || "Automatisation sans nom",\n    body: cleanBody,\n    attachments,\n    scheduledFor:'
)
replace_once(
    'src/domain/scheduledMessages.ts',
    '    createdByUserId: input.createdByUserId,\n    status:',
    '    recurrence: input.recurrence ?? "none",\n    enabled: true,\n    createdByUserId: input.createdByUserId,\n    createdByName: input.createdByName,\n    status:'
)

# Governance API schedule wire extensions/update.
replace_once(
    'src/services/api/governanceApi.ts',
    '  body?: unknown;\n  attachments?: unknown;\n  scheduled_for?: unknown;',
    '  name?: unknown;\n  body?: unknown;\n  attachments?: unknown;\n  scheduled_for?: unknown;\n  recurrence?: unknown;\n  enabled?: unknown;\n  created_by_name?: unknown;'
)
replace_once(
    'src/services/api/governanceApi.ts',
    '    body: typeof payload.body === "string" ? payload.body : fallback.body,',
    '    name: typeof payload.name === "string" ? payload.name : "Automatisation",\n    body: typeof payload.body === "string" ? payload.body : fallback.body,'
)
replace_once(
    'src/services/api/governanceApi.ts',
    '    createdByUserId:\n      typeof payload.created_by_user_id === "string"',
    '    recurrence:\n      payload.recurrence === "daily" || payload.recurrence === "weekly" || payload.recurrence === "monthly"\n        ? payload.recurrence\n        : "none",\n    enabled: payload.enabled !== false,\n    createdByUserId:\n      typeof payload.created_by_user_id === "string"'
)
replace_once(
    'src/services/api/governanceApi.ts',
    '        : "current-user",\n    status:',
    '        : "current-user",\n    createdByName: typeof payload.created_by_name === "string" ? payload.created_by_name : undefined,\n    status:'
)
replace_once(
    'src/services/api/governanceApi.ts',
    '    body: string;\n    attachments?: MessageAttachment[];\n    scheduledFor: string;',
    '    name?: string;\n    body: string;\n    attachments?: MessageAttachment[];\n    scheduledFor: string;\n    recurrence?: "none" | "daily" | "weekly" | "monthly";'
)
replace_once(
    'src/services/api/governanceApi.ts',
    '          body: input.body,\n          attachments,\n          scheduled_for: input.scheduledFor',
    '          name: input.name ?? null,\n          body: input.body,\n          attachments,\n          scheduled_for: input.scheduledFor,\n          recurrence: input.recurrence ?? "none"'
)
replace_once(
    'src/services/api/governanceApi.ts',
    '  async cancelScheduledMessage(',
    dedent('''
      async updateScheduledMessage(
        conversationId: string,
        scheduledMessageId: string,
        input: { name?: string; body: string; scheduledFor: string; recurrence?: "none" | "daily" | "weekly" | "monthly" }
      ): Promise<ScheduledMessage> {
        const payload = await authenticatedRequest<ScheduledMessageWire>(
          `/v1/conversations/${encodeURIComponent(conversationId)}/scheduled-messages/${encodeURIComponent(scheduledMessageId)}`,
          { method: "PATCH", body: JSON.stringify({ name: input.name ?? null, body: input.body, scheduled_for: input.scheduledFor, recurrence: input.recurrence ?? "none" }) },
          this.fallbackAccessToken
        );
        return normalizeScheduledMessage(payload, { conversationId, body: input.body, attachments: [], scheduledFor: input.scheduledFor });
      }

      async cancelScheduledMessage(''').rstrip()
)

# Replace whole schedule screen with the automation-oriented UX.
write('app/schedule-message/[id].tsx', dedent('''
    import { Ionicons } from "@expo/vector-icons";
    import * as Crypto from "expo-crypto";
    import { LinearGradient } from "expo-linear-gradient";
    import { router, useLocalSearchParams } from "expo-router";
    import { useEffect, useMemo, useState } from "react";
    import { ActivityIndicator, Alert, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from "react-native";
    import { useSafeAreaInsets } from "react-native-safe-area-context";

    import { env } from "@/config/env";
    import { isVisionnaire } from "@/domain/accessPolicy";
    import { canScheduleMessages, createScheduledMessage } from "@/domain/scheduledMessages";
    import { useExperience } from "@/providers/ExperienceProvider";
    import { useGroupAdmin } from "@/providers/GroupAdminProvider";
    import { useMessaging } from "@/providers/MessagingProvider";
    import { useSession } from "@/providers/SessionProvider";
    import { NeptuneGovernanceApi } from "@/services/api/governanceApi";
    import { colors, gradients, spacing, typography } from "@/theme";
    import type { ScheduledMessage } from "@/types/messaging";

    const PRESETS = [
      { id: "hour", label: "Dans 1 heure", minutes: 60 },
      { id: "tomorrow", label: "Demain à 9 h", resolve: () => { const d = new Date(); d.setDate(d.getDate() + 1); d.setHours(9, 0, 0, 0); return d; } },
      { id: "monday", label: "Lundi à 9 h", resolve: () => { const d = new Date(); d.setDate(d.getDate() + (((8 - d.getDay()) % 7) || 7)); d.setHours(9, 0, 0, 0); return d; } }
    ] as const;
    const RECURRENCES = [
      { value: "none", label: "Une fois" },
      { value: "daily", label: "Chaque jour" },
      { value: "weekly", label: "Chaque semaine" },
      { value: "monthly", label: "Chaque mois" }
    ] as const;

    function first(value?: string | string[]) { return Array.isArray(value) ? value[0] ?? "" : value ?? ""; }
    function formatDate(date: Date) { return new Intl.DateTimeFormat("fr-FR", { day: "2-digit", month: "2-digit", year: "numeric" }).format(date); }
    function formatTime(date: Date) { return new Intl.DateTimeFormat("fr-FR", { hour: "2-digit", minute: "2-digit", hour12: false }).format(date).replace(" h ", ":"); }
    function parseDate(dateValue: string, timeValue: string) {
      const dm = dateValue.match(/^(\\d{2})\\/(\\d{2})\\/(\\d{4})$/u);
      const tm = timeValue.match(/^(\\d{1,2}):(\\d{2})$/u);
      if (!dm || !tm) throw new Error("Utilisez les formats JJ/MM/AAAA et HH:MM.");
      const result = new Date(Number(dm[3]), Number(dm[2]) - 1, Number(dm[1]), Number(tm[1]), Number(tm[2]));
      if (!Number.isFinite(result.getTime())) throw new Error("Date invalide.");
      return result;
    }
    function formatScheduled(value: string) { return new Intl.DateTimeFormat("fr-FR", { weekday: "short", day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit" }).format(new Date(value)); }

    export default function GroupAutomationsScreen() {
      const params = useLocalSearchParams<{ id: string }>();
      const insets = useSafeAreaInsets();
      const conversationId = first(params.id);
      const { currentUser, accessToken } = useSession();
      const { getConversation: getServerConversation } = useMessaging();
      const { getConversation: getLocalConversation, members } = useExperience();
      const { getCreatedGroup } = useGroupAdmin();
      const conversation = getServerConversation(conversationId) ?? getLocalConversation(conversationId) ?? getCreatedGroup(conversationId);
      const responsible = Boolean(conversation?.adminIds?.includes(currentUser.id));
      const visionnaire = isVisionnaire(currentUser.role);
      const authorized = Boolean(conversation && conversation.type !== "direct" && canScheduleMessages(currentUser.role, responsible));
      const api = useMemo(() => env.mockMode ? null : new NeptuneGovernanceApi(accessToken), [accessToken]);
      const initial = useMemo(() => { const d = new Date(); d.setDate(d.getDate() + 1); d.setHours(9, 0, 0, 0); return d; }, []);
      const [items, setItems] = useState<ScheduledMessage[]>([]);
      const [name, setName] = useState("");
      const [body, setBody] = useState("");
      const [dateValue, setDateValue] = useState(formatDate(initial));
      const [timeValue, setTimeValue] = useState(formatTime(initial));
      const [recurrence, setRecurrence] = useState<ScheduledMessage["recurrence"]>("none");
      const [editingId, setEditingId] = useState<string | null>(null);
      const [loading, setLoading] = useState(false);
      const [saving, setSaving] = useState(false);

      useEffect(() => {
        if (!authorized || !api) return;
        setLoading(true);
        void api.listScheduledMessages(conversationId)
          .then((value) => setItems(value.filter((item) => item.status === "scheduled").sort((a, b) => Date.parse(a.scheduledFor) - Date.parse(b.scheduledFor))))
          .catch(() => setItems([]))
          .finally(() => setLoading(false));
      }, [api, authorized, conversationId]);

      const reset = () => { setName(""); setBody(""); setRecurrence("none"); setEditingId(null); const next = new Date(); next.setDate(next.getDate() + 1); next.setHours(9, 0, 0, 0); setDateValue(formatDate(next)); setTimeValue(formatTime(next)); };
      const applyPreset = (preset: typeof PRESETS[number]) => { const date = "resolve" in preset ? preset.resolve() : new Date(Date.now() + preset.minutes * 60_000); setDateValue(formatDate(date)); setTimeValue(formatTime(date)); };
      const edit = (item: ScheduledMessage) => { setEditingId(item.id); setName(item.name ?? ""); setBody(item.body); setRecurrence(item.recurrence ?? "none"); const d = new Date(item.scheduledFor); setDateValue(formatDate(d)); setTimeValue(formatTime(d)); };
      const canManageItem = (item: ScheduledMessage) => visionnaire || item.createdByUserId === currentUser.id;

      const save = async () => {
        if (!authorized || saving) return;
        const cleanBody = body.trim();
        if (!cleanBody) { Alert.alert("Message requis", "Écrivez le message de l’automatisation."); return; }
        setSaving(true);
        try {
          const scheduledFor = parseDate(dateValue, timeValue).toISOString();
          const base = createScheduledMessage({
            id: editingId ?? `scheduled-${Crypto.randomUUID()}`,
            conversationId,
            name: name.trim() || undefined,
            body: cleanBody,
            scheduledFor,
            recurrence: recurrence ?? "none",
            createdByUserId: currentUser.id,
            createdByName: currentUser.name,
            role: currentUser.role,
            canManageConversation: responsible
          });
          const saved = api
            ? editingId
              ? await api.updateScheduledMessage(conversationId, editingId, { name: base.name, body: base.body, scheduledFor: base.scheduledFor, recurrence: base.recurrence })
              : await api.scheduleMessage({ conversationId, name: base.name, body: base.body, scheduledFor: base.scheduledFor, recurrence: base.recurrence })
            : base;
          setItems((previous) => [...previous.filter((item) => item.id !== saved.id), { ...saved, createdByName: saved.createdByName ?? currentUser.name }].sort((a, b) => Date.parse(a.scheduledFor) - Date.parse(b.scheduledFor)));
          reset();
        } catch (error) {
          Alert.alert("Automatisation impossible", error instanceof Error ? error.message : "Réessayez ultérieurement.");
        } finally { setSaving(false); }
      };

      const remove = async (item: ScheduledMessage) => {
        if (!canManageItem(item)) return;
        try { if (api) await api.cancelScheduledMessage(conversationId, item.id); setItems((previous) => previous.filter((candidate) => candidate.id !== item.id)); }
        catch (error) { Alert.alert("Suppression impossible", error instanceof Error ? error.message : "Réessayez ultérieurement."); }
      };

      if (!conversation || !authorized) {
        return <LinearGradient colors={gradients.screen} style={styles.center}><Ionicons name="lock-closed-outline" size={36} color={colors.orange} /><Text style={styles.title}>Automatisations non autorisées</Text><Text style={styles.description}>Seuls les Visionnaires et les responsables désignés de ce groupe y ont accès.</Text><Pressable onPress={() => router.back()} style={styles.secondary}><Text style={styles.secondaryText}>Retour</Text></Pressable></LinearGradient>;
      }

      return (
        <LinearGradient colors={gradients.screen} style={styles.screen}>
          <View style={[styles.header, { paddingTop: Math.max(insets.top, spacing.sm), paddingLeft: spacing.sm + insets.left, paddingRight: spacing.sm + insets.right }]}>
            <Pressable onPress={() => router.back()} style={styles.headerButton}><Ionicons name="chevron-back" size={25} color={colors.text} /></Pressable>
            <View style={styles.headerText}><Text style={styles.headerTitle}>Automatisations du groupe</Text><Text style={styles.headerSubtitle} numberOfLines={1}>{conversation.name}</Text></View>
            <View style={styles.shield}><Ionicons name="options" size={18} color={colors.orange} /></View>
          </View>
          <ScrollView contentContainerStyle={[styles.content, { paddingBottom: Math.max(insets.bottom, spacing.xl) }]} keyboardShouldPersistTaps="handled">
            <View style={styles.hero}><Ionicons name="infinite-outline" size={25} color={colors.orange} /><View style={styles.heroCopy}><Text style={styles.heroTitle}>Messages planifiés et récurrents</Text><Text style={styles.heroText}>Toutes les automatisations sont visibles par les responsables. Les Visionnaires peuvent modifier ou supprimer celles de toute l’équipe.</Text></View></View>
            <View style={styles.sectionHeader}><Text style={styles.sectionTitle}>Actives</Text><Text style={styles.count}>{items.length}</Text></View>
            {loading ? <ActivityIndicator color={colors.violet} /> : items.length === 0 ? <Text style={styles.empty}>Aucune automatisation active.</Text> : items.map((item) => {
              const author = item.createdByName ?? members.find((member) => member.id === item.createdByUserId)?.name ?? "Membre Neptune";
              return <View key={item.id} style={styles.card}><View style={styles.cardTop}><View style={styles.automationIcon}><Ionicons name={item.recurrence && item.recurrence !== "none" ? "repeat" : "calendar"} size={18} color={colors.orange} /></View><View style={styles.cardCopy}><Text style={styles.cardTitle}>{item.name ?? "Automatisation"}</Text><Text style={styles.cardMeta}>Par {author} · {formatScheduled(item.scheduledFor)}{item.recurrence && item.recurrence !== "none" ? ` · ${RECURRENCES.find((value) => value.value === item.recurrence)?.label}` : ""}</Text></View></View><Text style={styles.cardBody} numberOfLines={3}>{item.body}</Text>{canManageItem(item) ? <View style={styles.cardActions}><Pressable onPress={() => edit(item)} style={styles.smallAction}><Ionicons name="create-outline" size={17} color={colors.text} /><Text style={styles.smallText}>Modifier</Text></Pressable><Pressable onPress={() => void remove(item)} style={styles.smallAction}><Ionicons name="trash-outline" size={17} color={colors.danger} /><Text style={[styles.smallText, styles.danger]}>Supprimer</Text></Pressable></View> : null}</View>;
            })}
            <Text style={styles.sectionTitle}>{editingId ? "Modifier l’automatisation" : "Nouvelle automatisation"}</Text>
            <View style={styles.builder}>
              <Text style={styles.label}>Nom</Text><TextInput value={name} onChangeText={setName} placeholder="Ex. Rappel atelier du lundi" placeholderTextColor={colors.textMuted} style={styles.input} maxLength={80} />
              <Text style={styles.label}>Message</Text><TextInput value={body} onChangeText={setBody} placeholder="Message envoyé automatiquement…" placeholderTextColor={colors.textMuted} multiline style={styles.editor} maxLength={4000} />
              <Text style={styles.label}>Rythme</Text><View style={styles.chips}>{RECURRENCES.map((item) => <Pressable key={item.value} onPress={() => setRecurrence(item.value)} style={[styles.chip, recurrence === item.value && styles.chipActive]}><Text style={[styles.chipText, recurrence === item.value && styles.chipTextActive]}>{item.label}</Text></Pressable>)}</View>
              <Text style={styles.label}>Premier envoi</Text><View style={styles.chips}>{PRESETS.map((preset) => <Pressable key={preset.id} onPress={() => applyPreset(preset)} style={styles.chip}><Text style={styles.chipText}>{preset.label}</Text></Pressable>)}</View>
              <View style={styles.dateRow}><TextInput value={dateValue} onChangeText={setDateValue} placeholder="JJ/MM/AAAA" placeholderTextColor={colors.textMuted} style={[styles.input, styles.dateInput]} /><TextInput value={timeValue} onChangeText={setTimeValue} placeholder="HH:MM" placeholderTextColor={colors.textMuted} style={[styles.input, styles.timeInput]} /></View>
              <Pressable disabled={saving} onPress={() => void save()} style={[styles.primary, saving && styles.disabled]}>{saving ? <ActivityIndicator color={colors.white} /> : <Ionicons name={editingId ? "save" : "flash"} size={19} color={colors.white} />}<Text style={styles.primaryText}>{editingId ? "Enregistrer les modifications" : "Activer l’automatisation"}</Text></Pressable>
              {editingId ? <Pressable onPress={reset} style={styles.cancel}><Text style={styles.cancelText}>Annuler la modification</Text></Pressable> : null}
            </View>
          </ScrollView>
        </LinearGradient>
      );
    }

    const styles = StyleSheet.create({
      screen: { flex: 1 }, center: { flex: 1, alignItems: "center", justifyContent: "center", padding: spacing.xl, gap: 12 }, title: { ...typography.heading2, color: colors.text, textAlign: "center" }, description: { color: colors.textMuted, textAlign: "center", maxWidth: 440 }, secondary: { minHeight: 46, paddingHorizontal: 18, borderRadius: 15, backgroundColor: colors.surfaceStrong, justifyContent: "center" }, secondaryText: { color: colors.text, fontWeight: "900" },
      header: { minHeight: 64, paddingBottom: 8, flexDirection: "row", alignItems: "center" }, headerButton: { width: 48, height: 48, alignItems: "center", justifyContent: "center" }, headerText: { flex: 1, minWidth: 0 }, headerTitle: { ...typography.heading3, color: colors.text, textAlign: "center" }, headerSubtitle: { color: colors.textMuted, fontSize: 9, textAlign: "center", marginTop: 2 }, shield: { width: 48, height: 48, alignItems: "center", justifyContent: "center" },
      content: { width: "100%", maxWidth: 720, alignSelf: "center", paddingHorizontal: spacing.md }, hero: { minHeight: 96, padding: 15, borderRadius: 22, backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.borderSoft, flexDirection: "row", alignItems: "center", gap: 12 }, heroCopy: { flex: 1 }, heroTitle: { color: colors.text, fontSize: 13, fontWeight: "900" }, heroText: { color: colors.textMuted, fontSize: 9.5, lineHeight: 14, marginTop: 4 },
      sectionHeader: { marginTop: spacing.lg, flexDirection: "row", alignItems: "center", justifyContent: "space-between" }, sectionTitle: { ...typography.heading3, color: colors.text, marginTop: spacing.lg, marginBottom: 9 }, count: { color: colors.orange, fontWeight: "900" }, empty: { color: colors.textMuted, textAlign: "center", padding: 22, borderRadius: 18, backgroundColor: colors.surface },
      card: { marginBottom: 8, padding: 13, borderRadius: 19, backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.borderSoft }, cardTop: { flexDirection: "row", gap: 9, alignItems: "center" }, automationIcon: { width: 38, height: 38, borderRadius: 13, backgroundColor: "rgba(244,177,131,0.12)", alignItems: "center", justifyContent: "center" }, cardCopy: { flex: 1, minWidth: 0 }, cardTitle: { color: colors.text, fontSize: 12, fontWeight: "900" }, cardMeta: { color: colors.textMuted, fontSize: 8.5, marginTop: 3 }, cardBody: { color: colors.textSecondary, fontSize: 10.5, lineHeight: 15, marginTop: 9 }, cardActions: { marginTop: 8, flexDirection: "row", gap: 8 }, smallAction: { flex: 1, minHeight: 42, borderRadius: 13, backgroundColor: colors.surfaceStrong, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 6 }, smallText: { color: colors.text, fontSize: 9, fontWeight: "900" }, danger: { color: colors.danger },
      builder: { padding: 14, borderRadius: 22, backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.borderSoft }, label: { color: colors.textSecondary, fontSize: 9.5, fontWeight: "900", marginTop: 10, marginBottom: 6 }, input: { minHeight: 48, paddingHorizontal: 12, borderRadius: 15, borderWidth: 1, borderColor: colors.borderSoft, backgroundColor: colors.surfaceStrong, color: colors.text }, editor: { minHeight: 112, padding: 12, borderRadius: 16, borderWidth: 1, borderColor: colors.borderSoft, backgroundColor: colors.surfaceStrong, color: colors.text, textAlignVertical: "top" }, chips: { flexDirection: "row", flexWrap: "wrap", gap: 7 }, chip: { minHeight: 42, paddingHorizontal: 11, borderRadius: 999, borderWidth: 1, borderColor: colors.borderSoft, backgroundColor: colors.surfaceStrong, alignItems: "center", justifyContent: "center" }, chipActive: { borderColor: colors.violet, backgroundColor: "rgba(107,79,234,0.20)" }, chipText: { color: colors.textMuted, fontSize: 9, fontWeight: "800" }, chipTextActive: { color: colors.text }, dateRow: { marginTop: 8, flexDirection: "row", gap: 8 }, dateInput: { flex: 2 }, timeInput: { flex: 1 }, primary: { minHeight: 52, marginTop: 14, borderRadius: 17, backgroundColor: colors.primary, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 8 }, primaryText: { color: colors.white, fontSize: 12, fontWeight: "900" }, disabled: { opacity: 0.5 }, cancel: { minHeight: 44, alignItems: "center", justifyContent: "center" }, cancelText: { color: colors.textMuted, fontSize: 10, fontWeight: "800" }
    });
''').strip() + '\n')

# ---------------------------------------------------------------------------
# Free plan gates: new private conversations, calls and highlight types.
# ---------------------------------------------------------------------------
replace_once(
    'src/screens/NewConversationScreen.tsx',
    '  Image,\n  Pressable,',
    '  Image,\n  Linking,\n  Pressable,'
)
replace_once(
    'src/screens/NewConversationScreen.tsx',
    'import {\n  GROUP_VISIBILITY_ROLES,',
    'import { canInitiatePrivateInteraction, TRITON_CHECKOUT_URL } from "../domain/accessPolicy";\nimport {\n  GROUP_VISIBILITY_ROLES,'
)
replace_once(
    'src/screens/NewConversationScreen.tsx',
    'import { colors, gradients, radii, spacing, typography } from "../theme";',
    'import { colors, gradients, radii, spacing, typography } from "../theme";\nimport { MemberStatusBadge } from "../components/MemberStatusBadge";'
)
replace_once(
    'src/screens/NewConversationScreen.tsx',
    '  const canCreateOfficialGroup = isVisionnaireRole(currentUser.role);',
    '  const canCreateOfficialGroup = isVisionnaireRole(currentUser.role);\n  const canInitiatePrivate = canInitiatePrivateInteraction(currentUser.role);'
)
replace_once(
    'src/screens/NewConversationScreen.tsx',
    '  const toggleMember = (memberId: string) => {\n    setSelectedIds(',
    '  const toggleMember = (memberId: string) => {\n    if (!canInitiatePrivate) {\n      Alert.alert("Fonction réservée aux membres", "Passez Triton pour démarrer une discussion privée.", [\n        { text: "Annuler", style: "cancel" },\n        { text: "Passer Triton", onPress: () => void Linking.openURL(TRITON_CHECKOUT_URL) }\n      ]);\n      return;\n    }\n    setSelectedIds('
)
replace_once(
    'src/screens/NewConversationScreen.tsx',
    '    if (mode === "private") {\n      if (selectedIds.length === 0)',
    '    if (mode === "private") {\n      if (!canInitiatePrivate) {\n        await Linking.openURL(TRITON_CHECKOUT_URL);\n        return;\n      }\n      if (selectedIds.length === 0)'
)
replace_once(
    'src/screens/NewConversationScreen.tsx',
    '            <View style={styles.infoCard}>\n              <Ionicons name="shield-checkmark"',
    '            {!canInitiatePrivate ? (\n              <Pressable onPress={() => void Linking.openURL(TRITON_CHECKOUT_URL)} style={[styles.infoCard, styles.upgradeCard]}>\n                <Ionicons name="lock-closed" size={19} color={colors.orange} />\n                <Text style={styles.infoText}>Les comptes Free peuvent recevoir une invitation, mais doivent passer Triton pour démarrer une discussion ou un appel.</Text>\n                <Text style={styles.upgradeText}>Passer Triton</Text>\n              </Pressable>\n            ) : null}\n            <View style={styles.infoCard}>\n              <Ionicons name="shield-checkmark"'
)
replace_once(
    'src/screens/NewConversationScreen.tsx',
    '                    <View style={styles.memberContent}>\n                      <Text style={styles.memberName}>{member.name}</Text>',
    '                    <View style={styles.memberContent}>\n                      <View style={styles.memberNameLine}>\n                        <Text style={styles.memberName}>{member.name}</Text>\n                        <MemberStatusBadge role={member.role} compact />\n                      </View>'
)
replace_once(
    'src/screens/NewConversationScreen.tsx',
    '  memberName: { color: colors.text, fontSize: 12, fontWeight: "900" },',
    '  memberNameLine: { flexDirection: "row", alignItems: "center", gap: 6 },\n  memberName: { color: colors.text, fontSize: 12, fontWeight: "900", flexShrink: 1 },'
)
replace_once(
    'src/screens/NewConversationScreen.tsx',
    '  infoText: {',
    '  upgradeCard: { borderColor: "rgba(244,177,131,0.32)" },\n  upgradeText: { color: colors.orange, fontSize: 9.5, fontWeight: "900" },\n  infoText: {'
)

# New group draft can expose Free visibility.
replace_once(
    'src/screens/NewConversationScreen.tsx',
    '  const [membersCanPost, setMembersCanPost] = useState(true);',
    '  const [membersCanPost, setMembersCanPost] = useState(true);\n  const [freeJoinAllowed, setFreeJoinAllowed] = useState(false);'
)
replace_once(
    'src/screens/NewConversationScreen.tsx',
    '        canMembersPost: membersCanPost,\n        iconName,',
    '        canMembersPost: membersCanPost,\n        freeJoinAllowed,\n        iconName,'
)
# add switch before membersCanPost group setting by exact phrase.
replace_once(
    'src/screens/NewConversationScreen.tsx',
    '            <View style={styles.settingRow}>\n              <View style={styles.settingText}>\n                <Text style={styles.settingTitle}>Les membres peuvent publier</Text>',
    '            <View style={styles.settingRow}>\n              <View style={styles.settingText}>\n                <Text style={styles.settingTitle}>Visible aux comptes Free</Text>\n                <Text style={styles.settingSubtitle}>Ils devront passer Triton avant de pouvoir rejoindre le groupe.</Text>\n              </View>\n              <Switch value={freeJoinAllowed} onValueChange={setFreeJoinAllowed} trackColor={{ false: colors.surfaceMuted, true: colors.primary }} thumbColor={colors.white} />\n            </View>\n\n            <View style={styles.settingRow}>\n              <View style={styles.settingText}>\n                <Text style={styles.settingTitle}>Les membres peuvent publier</Text>'
)

# Calls gate.
replace_once(
    'app/call/[id].tsx',
    '  Alert,\n  Pressable,',
    '  Alert,\n  Linking,\n  Pressable,'
)
replace_once(
    'app/call/[id].tsx',
    'import { colors, gradients, spacing, typography } from "@/theme";',
    'import { colors, gradients, spacing, typography } from "@/theme";\nimport { canInitiatePrivateInteraction, TRITON_CHECKOUT_URL } from "@/domain/accessPolicy";'
)
replace_once(
    'app/call/[id].tsx',
    '  const { accessToken } = useSession();',
    '  const { accessToken, currentUser } = useSession();'
)
replace_once(
    'app/call/[id].tsx',
    '  const startOutgoingCall = async () => {\n    if (preparing) return;',
    '  const startOutgoingCall = async () => {\n    if (preparing) return;\n    if (!incoming && !canInitiatePrivateInteraction(currentUser.role)) {\n      Alert.alert("Appels réservés aux membres", "Les comptes Free peuvent recevoir un appel, mais doivent passer Triton pour en initier un.", [\n        { text: "Annuler", style: "cancel" },\n        { text: "Passer Triton", onPress: () => void Linking.openURL(TRITON_CHECKOUT_URL) }\n      ]);\n      return;\n    }'
)

# Highlights: Free starts on Besoin and other kinds trigger upgrade.
replace_once(
    'app/new-highlight.tsx',
    '  Alert,\n  Animated,',
    '  Alert,\n  Animated,\n  Linking,'
)
replace_once(
    'app/new-highlight.tsx',
    'import { env } from "@/config/env";',
    'import { env } from "@/config/env";\nimport { canCreateHighlightKind, isFreeRole, TRITON_CHECKOUT_URL } from "@/domain/accessPolicy";'
)
replace_once(
    'app/new-highlight.tsx',
    '  const { accessToken } = useSession();',
    '  const { accessToken, currentUser } = useSession();'
)
replace_once(
    'app/new-highlight.tsx',
    '  const [kind, setKind] = useState<HighlightKind>("standard");',
    '  const [kind, setKind] = useState<HighlightKind>(\n    isFreeRole(currentUser.role) ? "besoin" : "standard"\n  );'
)
replace_once(
    'app/new-highlight.tsx',
    '  const mentionQuery = useMemo(() => {',
    '  const chooseKind = (nextKind: HighlightKind) => {\n    if (!canCreateHighlightKind(currentUser.role, nextKind)) {\n      Alert.alert("Publication réservée aux membres", "Avec le compte Free, vous pouvez publier uniquement un Besoin. Passez Triton pour partager des Temps forts, Réussites et Offres.", [\n        { text: "Annuler", style: "cancel" },\n        { text: "Passer Triton", onPress: () => void Linking.openURL(TRITON_CHECKOUT_URL) }\n      ]);\n      return;\n    }\n    setKind(nextKind);\n  };\n\n  const mentionQuery = useMemo(() => {'
)
replace_once('app/new-highlight.tsx', '                onPress={() => setKind(item.value)}', '                onPress={() => chooseKind(item.value)}')

# ---------------------------------------------------------------------------
# Notification sound configuration.
# ---------------------------------------------------------------------------
replace_once(
    'app.config.ts',
    '      [\n        "expo-notifications",\n        {\n          defaultChannel: "messages"\n        }\n      ],',
    '      [\n        "expo-notifications",\n        {\n          defaultChannel: "messages",\n          sounds: ["./assets/audio/connexio-notification.mp3"]\n        }\n      ],'
)
replace_all(
    'src/services/notifications/pushNotifications.ts',
    'sound: "default"',
    'sound: "connexio-notification.mp3"'
)

# ---------------------------------------------------------------------------
# Type-safe formatting pass for known malformed fragments.
# ---------------------------------------------------------------------------
# Ensure no accidental `if False` artifact and normalize trailing spaces.
for path in [
    'src/components/MessageBubble.tsx',
    'src/components/MessageAttachmentView.tsx',
    'app/chat/[id].tsx',
    'app/group/[id].tsx',
    'src/screens/NewConversationScreen.tsx'
]:
    content = read(path).replace(' \n', '\n')
    write(path, content)

print('V14 governance/access/audio patch applied')
